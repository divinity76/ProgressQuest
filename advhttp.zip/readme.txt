
		Advanced Http - Asynchronous Wininet Component

			Version 1.3,  16-01-99

Introduction:
-------------
This component implements a complete encapsulation of http protocol for the
Microsoft Wininet api.

Main features:
* Asynchronous-nonblocking http transactions.
* 33 properties and 18 events giving full control over the http protocol.
* Allows multiple, concurrent, nonblocking http transactions.
* Server and proxy authentication with standard or user defined dialogs.
* Easy SSL/PCT secure transactions.
* It can handle text and binary data.

Installation:
-------------
In Delphi, go to Components/Install Packages menu item, click on Add button and 
select kAdvHttp.bpl file. The TAdvHttp component will apear in Samples tab of the 
delphi components pallette.

Changes from version 1.0
------------------------

History:
30-01-99. Release Version 1.0.
03-02-99. Fixed authentication error when setting UserName and Password before
           execute the Start method.
03-02-99. Fixed event fire OnRequestComplete before process authentication.
20-02-99. Fixed parsing of response headers.
13-03-99. Added StartSync method.
13-03-99. Added ConnectTimeout property.
16-03-99. Fixed memory leak at GetBody.
16-03-99. Fixed resource leak at Cleanup.
18-03-99. Added SynchronizeEvent property.
18-03-99. Release Version 1.1
30-06-99. Fixed Extrainfo property not passed to HttpRequest.
20-07-99. Fixed not syncronized access to FStatusInformation in RequestComplete method
20-07-99. Release Version 1.2
26-08-99. Fixed CloseHandle(hThread) in Cleanup.
16-12-99. Changed Start and StartSync Method. Added true syncronous processing.
16-01-99. Release Version 1.3.


Registration:
-------------
This component is freeware, but if you wish the source code you must register.
Registration is only US$ 25. After you registered, you get the full source code
and lifetime free upgrades.

See Register.txt for details on ordering.

If you wish contact me for any question:

Gustavo Ricardi
Suipacha 190 Of. 407
(1008) Capital Federal 
Buenos Aires - Argentina
Tel.: 54-11-4326-8763
Fax.: 54-11-4326-5510
email: gricardi@teamsoft.com.ar

(c) on this component and all documents enclosed by Gustavo Ricardi, 1999.


*********************************************************************
*************************   DISCLAIMER   ****************************
*********************************************************************
This software is provided on an "as-is" basis, with no warranties,
express or implied.  The entire risk and liability of using it is yours.
Any damages resulting from the use or misuse of this software will be 
the responsibility of the user.
*********************************************************************